package sales;

public class SalesMan {

}
