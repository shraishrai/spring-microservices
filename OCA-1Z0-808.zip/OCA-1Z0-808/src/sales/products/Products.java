package sales.products;

public class Products {

}
