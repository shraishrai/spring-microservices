package com.sample;

import java.util.ArrayList;

public class Question_75 {
	public static void main(String[] args) {
		ArrayList<Integer> al = new ArrayList<Integer>();
		al.add(1);
		al.add(2);
		al.add(3);
		al.add(4);
		al.add(null);
		al.remove(1);
		al.remove(null);
		System.out.println(al);
	}
}

// A. A NullPointerException is thrown at runtime.
// B. [1, 2, 4]
// C. [1, 2, 4, null]
// D. [1, 3, 4, null]
/** E. [1, 3, 4] */
// F. Compilation fails.