package com.sample;

public class Question_98 {
	int x, y;

	public Question_98(int x, int y) {
		initialize(x, y);
	}

	public void initialize(int x, int y) {
		this.x = x * x;
		this.y = y * y;
	}

	public static void main(String[] args) {
		int x = 3, y = 5;

		Question_98 q = new Question_98(x, y);
		System.out.println(x + " " + y);
	}
}

//	A. Compilation fails.
/**	B. 3 5 */
//	C. 0 0
//	D. 9 25
