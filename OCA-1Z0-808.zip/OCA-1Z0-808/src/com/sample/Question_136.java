package com.sample;

class LogFileException extends Exception {
}

class AccessViolationException extends RuntimeException {
}

public class Question_136 {
	public static void main(String[] args) {
		Question_136 q = new Question_136();
		try {
			q.open();
			q.process();

			// Insert Code Here

		} catch (Exception e) {
			System.out.println("Completed.");
		}
	}

	// Consider as Line 13
	public void process() {
		System.out.println("Processed...");
		throw new LogFileException();
	}

	public void open() {
		System.out.println("Opened...");
		throw new AccessViolationException();
	}
}

//	A. At line 17, add throws AccessViolationException
/**	B. At line 13, add throws LogFileException */
//	C. At line 2, replace throws LogFileException with throws AccessViolationException
//	D. At line 7, insert throw new LogFileException ();