package com.sample;

public class Question_50 {
	static double area;
	int b = 2, h = 3;

	public static void main(String[] args) {
		double p, b, h; // Line 1

		if (area == 0) {
			b = 3;
			h = 4;
			p = 0.5;

			area = p * b * h; // Line 2
		}
		
		System.out.println("Area is: " + area);
	}
}

/**	A. Area is 6.0 */
//	B. Area is 3.0
//	C. Compilation fails at line n1
//	D. Compilation fails at line n2.