package com.sample;

class Animals {
	String type = "Canine";
	int maxSpeed = 60;

	Animals() {

	}

	Animals(String type, int maxSpeed) {
		this.type = type;
		this.maxSpeed = maxSpeed;
	}
}

class WildAnimals extends Animals {
	String bounds;

	WildAnimals(String bounds) {
		// Line 1

	}

	WildAnimals(String type, int maxSpeed, String bounds) {
		// Line 2

	}
}

public class Question_66 {
	public static void main(String[] args) {
		WildAnimals wolf = new WildAnimals("Long");
		WildAnimals tiger = new WildAnimals("Feline", 80, "Short");

		System.out.println(wolf.type + ", " + wolf.maxSpeed + ", " + wolf.bounds);
		System.out.println(tiger.type + ", " + tiger.maxSpeed + ", " + tiger.bounds);
	}
}

// O/P should be "Canine 60 Long" /n "Feline 80 Short"

// Answer A & E to get the O/P

/**
	//  A.
	//  Replace line 1 with
	//  super();
	//  this.bounds = bounds;
*/

//  B.
//  Replace line 1 with
//  this.bounds = bounds;
//  super();

//  C.
//  Replace line 2 with
//  super(type, maxSpeed);
//  this(bounds);

//  D. 
//  Replace line 1 with
//  this("Canine", 60);
//  this.bounds = bounds;

/**
	//  E. 
	//  Replace line 2 with
	//  super(type, maxSpeed);
	//  this.bounds = bounds;
*/