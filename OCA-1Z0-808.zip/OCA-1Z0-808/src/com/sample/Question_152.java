package com.sample;

public class Question_152 {
	public static void main(String[] args) {
		StringBuilder sb = new StringBuilder("Kishore");
		System.out.println(sb);

		// Line 1
	}
}

// Which statement will empty the contents of a StringBuilder variable named sb??

// A. sb.deleteAll();
// B. sb.delete(0, sb.size());
/** C. sb.delete(0, sb.length()); */
// D. sb.removeAll();
