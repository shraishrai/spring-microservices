package com.sample;

interface Readable {
	public void readBook();
	public void setBookMark();
}

abstract class Book implements Readable { // Line 1
	public void readBook() {
	}
	// Line 2
}

class EBook extends Book { // Line 3
	public void readBook() {
	}

	// Line 4
	// Insert Option "D" here to remove compile error
}

public class Question_09 {

	public static void main(String[] args) {
		Book book1 = new EBook();
		book1.readBook();
	}
}

/** D. All Compile time error gone */


// 	A. 
//	Replace the code fragment at Line 1 with:
//	class Book implements Readable {

// 	B. 
//	At Line 2 insert:
//	public abstract void setBookMark();

// 	C.
//	Replace the code fragment at Line 3 with:
//	abstract class EBook extends Book {

/**
	// 	D. 
	//	At Line 4 insert:
	//	public void setBookMark() { }
*/