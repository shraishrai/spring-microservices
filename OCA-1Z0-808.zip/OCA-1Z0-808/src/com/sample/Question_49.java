package com.sample;

abstract class Animal { }

interface Hunter { }

class Cat extends Animal implements Hunter { }

class Tiger extends Cat { }

public class Question_49 {
	public static void main(String[] args) {
		
		// Line 1
	}
}

//	Which answer fails to compile?

//	A
//	ArrayList<Animal> a1 = new ArrayList<>();
//	a1.add(new Tiger());

//	B
//	ArrayList<Hunter> a2 = new ArrayList<>();
//	a2.add(new Cat());

//	C
//	ArrayList<Hunter> a3 = new ArrayList<>();
//	a3.add(new Tiger());

/**
	//	D
	//	ArrayList<Tiger> a4 = new ArrayList<>();
	//	a4.add(new Cat());
*/

//	E
//	ArrayList<Animal> a5 = new ArrayList<>();
//	a5.add(new Cat());
