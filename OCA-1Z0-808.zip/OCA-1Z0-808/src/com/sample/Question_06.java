package com.sample;

class Caller {
	private void init() {
		System.out.println("Initialized");
	}

	private void start() {
		init();
		System.out.println("Started");
	}
}

public class Question_06 {

	public static void main(String[] args) {
		Caller c = new Caller();
		c.start(); // line n1
		c.init(); // line n2
	}
}

// A. Compilation fails at line n1
// B. Initialized Started Initialized
// C. Initialized Started
// D. Compilation fails at line n2
/** E. Compilation fails at line 1 and line n2 */