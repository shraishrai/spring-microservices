package com.sample;

public class Question_73 {
	String name;
	int age = 25;

	Question_73(String name) {
		setName(name); // Line 1
	}

	Question_73(String name, int age) {
		Question_73(name); // Line 2
		setAge(age);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String show() {
		return name + " " + age;
	}

	public static void main(String[] args) {
		Question_73 q1 = new Question_73("Jesse");
		Question_73 q2 = new Question_73("Walter", 52);

		System.out.println(q1.show());
		System.out.println(q2.show());
	}
}

// A. Compilation fails at both line n1 and line n2.
/** // B. Compilation fails only at line n2. */
// C. Compilation fails only at line n1.
// D. Jesse 25, Walter 52