package com.sample;

class CheckingAmt {
	public int amount;

	public CheckingAmt(int amount) {
		this.amount = amount;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public void changeAmount(int x) {
		amount += x;
	}
}

public class Question_13 {

	public static void main(String[] args) {
		CheckingAmt acct = new CheckingAmt((int) (Math.random() * 1000));

		// Line 1

		System.out.println(acct.getAmount());
	}
}

// A. acct.setAmount(-acct.getAmount());
/** 	B. acct.amount = 0; <option D earlier> */
/** 	C. acct.setAmount(0); */
// D. acct.getAmount() = 0; <option E earlier>
// E. this.amount = 0; <option A earlier>
// F. acct.changeAmount(0); <option F earlier>
/** 	G. acct.changeAmount(-acct.amount); <option G earlier> */
