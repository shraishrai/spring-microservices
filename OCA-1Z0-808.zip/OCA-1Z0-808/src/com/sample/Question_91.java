package com.sample;

class Studentts {
	String name;
	int age;
}

public class Question_91 {
	
	public static void main(String[] args) {
		Studentts s1 = new Studentts();
		Studentts s2 = new Studentts();
		Studentts s3 = new Studentts();

		s1 = s3;
		s3 = s2;
		s2 = null;
	}
}

//	A. After line 17, three objects are eligible for garbage collection.
//	B. After line 17, two objects are eligible for garbage collection.
/** C. After line 17, one object is eligible for garbage collection. */
//	D. After line 17, none of the objects are eligible for garbage collection.
