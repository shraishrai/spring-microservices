package com.sample;

class CD {
	int r;

	CD(int r) {
		this.r = r;
	}
}

class DVD extends CD {
	int c;

	DVD(int r, int c) {
		// Line 1
	}
}

public class Question_11 {

	public static void main(String[] args) {
		DVD dvd = new DVD(10, 20);
	}
}

// 	A. 
//	super.r = r;
// 	this.c = c;

// 	B.
//	super(r);
//	this(c);

/**
	// 	C.
	//	super(r);
	//	this.c = c;
*/

// 	D.
//	this.c = r;
//	super(c);