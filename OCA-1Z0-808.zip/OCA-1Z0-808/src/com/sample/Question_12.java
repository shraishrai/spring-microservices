package com.sample;

public class Question_12 {
	public static void main(String[] args) {
		int a[] = { 1, 2, 3, 4, 5 };

		for (/** Line 1 */) {
			System.out.print(a[e] + ", ");
		}
	}
}

// O/P need to be 1, 3, 5

// A. int e = 0; e <= 4; e++
/** B. int e = 0; e < 5; e += 2 */
// C. int e = 1; e <= 5; e += 1
// D. int e = 1; e < 5; e += 2
