package com.sample;

import com.p1.Acc;

public class Question_36 extends Acc {
	public static void main(String[] args) {
		Acc obj = new Acc();

		// Line 1
		
	}

}

//	Which statement is true?
/*
 * int p; 
 * private int q; 
 * protected int r; 
 * public int s;
 */

//	A. Both p and s are accessible via obj.
/** B. Only s is accessible via obj. */
//	C. Both r and s are accessible via obj.
//	D. p, r, and s are accessible via obj.