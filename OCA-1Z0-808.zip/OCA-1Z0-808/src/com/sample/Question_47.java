package com.sample;

public class Question_47 {
	public static void main(int[] args) {
		System.out.println("int main " + args[0]);
	}

	public static void main(Object[] args) {
		System.out.println("Object main " + args[0]);
	}

	public static void main(String[] args) {
		System.out.println("String main " + args[0]);
	}
}

// When we compile 
// javac filename.java
// java filename 1 2 3

// A. int main 1
// B. Object main 1
/** C. String main 1 */
// D. Compilation fails
// E. An exception is thrown at runtime