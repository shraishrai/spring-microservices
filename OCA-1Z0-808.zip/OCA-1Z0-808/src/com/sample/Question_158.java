package com.sample;

class Employiee1 {
	public int salary;
}

class Managier1 extends Employiee1 {
	public int budget;
}

class Directior1 extends Managier1 {
	public int stockOptions;
}

public class Question_158 {
	public static void main(String[] args) {
		Employiee1 e = new Employiee1();
		Managier1 m = new Managier1();
		Directior1 d = new Directior1();

		d.stockOptions = 1_000;
		e.salary = 50_000;
		m.budget = 1_000_000;
		m.stockOption = 500;
		e.budget = 200_000;
		d.salary = 80_000;

	}
}

//Which two options not compile when placed at line n1 of the main method? (Choose two.)

//Answer is B & F

// A. director.stockOptions = 1_000;
// B. employee.salary = 50_000; 
// C. manager.budget = 1_000_000;
/** D. manager.stockOption = 500; */
/** E. employee.budget = 200_000; */
// F. director.salary = 80_000; 
