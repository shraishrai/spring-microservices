package com.sample;

class MyString {
	String msg;

	MyString(String msg) {
		this.msg = msg;
	}
}

public class Question_45 {
	public static void main(String[] args) {
		System.out.println("Hello" + new StringBuilder(" Java SE 8"));
		System.out.println("Hello" + new MyString(" Java SE 8"));
	}
}

//	A.
//	Hello Java SE 8
//	Hello Java SE 8

//	B.
//	Hello java.lang.StringBuilder@<<hascode>>
//	Hello com.sample.MyString@@<<hascode>>

/**
	//  C.
	//	Hello  Java SE 8
	//	Hello com.sample.MyString@<<hascode>>
*/

//  D. Compilation fails at the Test class