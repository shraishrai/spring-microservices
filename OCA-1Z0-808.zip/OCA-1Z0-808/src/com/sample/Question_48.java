package com.sample;

class Planet1 {
	public String name;
	public int moons;

	Planet1(String name, int moons) {
		this.name = name;
		this.moons = moons;
	}
}

public class Question_48 {
	public static void main(String[] args) {
		Planet1[] planet = { new Planet1("Mercury", 0), new Planet1("Venus", 0), new Planet1("Earth", 1),
				new Planet1("Mars", 2) };

		System.out.println(planet);
		System.out.println(planet[2].name);
		System.out.println(planet[2].moons);
	}
}

//	A.
//	planets
//	Earth
//	1

/**
	//	B.
	//	[Lcom.sample.Planet1;@15db9742
	//	Earth
	//	1
*/

//	C.
//	[Lcom.sample.Planet1;@15db9742
//	Planets.Planet;@15db9742
//	1

//	C.
//	[Lcom.sample.Planet1;@15db9742
//	Planets.Planet;@15db9742
//	[LPlanets.Moon;@15db9742

//	E.
//	[Lcom.sample.Planet1;@15db9742
//	Venus
//	0

