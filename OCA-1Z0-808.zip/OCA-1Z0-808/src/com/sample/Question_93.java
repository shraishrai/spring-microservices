package com.sample;

import java.time.LocalDate;

public class Question_93 {
	public static void main(String[] args) {
		LocalDate ld = LocalDate.of(2012, 01, 32);
		ld.plusDays(10);

		System.out.println(ld);
	}
}

//	A. 2012-02-10
//	B. 2012-02-11
//	C. Compilation fails
/** D. A DateTimeException is thrown at runtime. */