package com.sample;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Question_121 {
	public static void main(String[] args) {

		LocalDateTime ldt = LocalDateTime.of(2014, 7, 31, 1, 1);
		ldt.plusDays(30);
		ldt.plusMonths(1);

		System.out.println(ldt.format(DateTimeFormatter.ISO_DATE_TIME));
	}
}

//	A. An exception is thrown at runtime.
/** B. 2014-07-31T01:01:00 */
//	C. 2014-07-31
//	D. 2014-09-30T00:00:00