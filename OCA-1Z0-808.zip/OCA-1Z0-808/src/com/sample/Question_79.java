package com.sample;

public class Question_79 {
	public static void main(String[] args) {
		int[] stack = { 10, 20, 30 };
		int size = 3;
		int idx = 0;

		// Line 1

		System.out.println("The top elements: " + stack[idx]);
	}
}

// Which code fragment, inserted at line 1, prints The Top element: 30?

// A.
// do {
//   idx++;
// } while (idx >= size);

// B.
// while (idx < size) {
//   idx++;
// }

/**
	// C.
	// do {
	//	 idx++;
	// } while (idx < size - 1);
*/

// D.
// do {
//   idx++;
// } while (idx <= size);

// E.
// while (idx <= size - 1) {
//   idx++;
// }