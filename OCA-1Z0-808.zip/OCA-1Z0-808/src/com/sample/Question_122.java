package com.sample;

class Employeeis {
	private String name;
	private int age;
	private int salary;

	public Employeeis(String name, int age) {
		setName(name);
		setAge(age);
		setSalary(2000);
	}

	public Employeeis(String name, int age, int salary) {
		this(name, age);
		setSalary(salary);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	public void printDetails() {
		System.out.println(name + " : " + age + " : " + salary);
	}
}

// Consider this "Question_122" class as "Test" class
public class Question_122 {
	public static void main(String[] args) {
		Employeeis e1 = new Employeeis();
		Employeeis e2 = new Employeeis("Jack", 50);
		Employeeis e3 = new Employeeis("Chole", 40, 5000);

		e1.printDetails();
		e2.printDetails();
		e3.printDetails();
	}
}

//	A. Compilation fails in the Employee class.

//	B.
//	null : 0 : 0
//	Jack : 50 : 0
//	Chole : 40 : 5000

//	C.
//	null : 0 : 0
//	Jack : 50 : 2000
//	Chole : 40 : 5000

/** D. Compilation fails in the Test class. */

//	E. Both the Employee class and the Test class fail to compile.
