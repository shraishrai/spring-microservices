package com.sample;

public class Question_33 {
	public static void main(String[] args) {
		String s = "hello";

		if (s.equals("hello") ? true : false) {
			System.out.println("Success");
		} else {
			System.out.println("Failure");
		}
	}
}

/** A. Success */
// 	B. Failure
//	C. Compilation Fails
//	D. An Exception is thrown at runtime
