package com.sample;

public class Question_25 {
	public static void main(String[] args) {

		// Line 1
		
		array[0] = 10;
		array[1] = 20;

		System.out.println(array[0] + " : " + array[1]);
	}
}

/** Choose the option to print "10 : 20" */

// A. int[] array = new int[1];

/**
	//	B. 
	//	int[] array;
	//	array = new int[2];
*/

//	C. int array = new int[2];

//	D. int array[1];