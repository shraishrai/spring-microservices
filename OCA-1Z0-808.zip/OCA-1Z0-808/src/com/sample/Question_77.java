package com.sample;

public class Question_77 {
	public static void main(String[] args) {

		// Line 1

	}
}

// Which two makes complie time error?


// A. float flt = 100.00F;

// B. float flt1 = (float) 1_11.00;

/**
	// C. Float flt2 = 100.00;
	
	// D. 
	// double dbl = 203.22;
	// float flt3 = dbl;
*/

// E
// int it = 100;
// float flt4 = (float) it;