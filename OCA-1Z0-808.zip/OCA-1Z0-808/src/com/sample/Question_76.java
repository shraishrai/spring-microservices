package com.sample;

public class Question_76 {
	public static void main(String[] args) {
		int number[];
		number = new int[2];
		number[0] = 10;
		number[1] = 20;

		number = new int[4];
		number[2] = 30;
		number[3] = 40;

		for (int x : number) {
			System.out.print(x + " ");
		}
	}
}

// A. 10 20 30 40
/** B. 0 0 30 40 */
// C. Compilation fails.
// D. An exception is thrown at runtime.