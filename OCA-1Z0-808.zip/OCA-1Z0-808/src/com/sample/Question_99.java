package com.sample;

public class Question_99 {
	public static void main(String[] args) {
		int[] array = { 10, 20, 30, 40, 50 };
		int x = array.length;

		// Line 1

	}
}

// Print the elements in reverse order as "50, 40, 30, 20, 10".

/**
	//  A:
	//	while (x > 0) {
	//		x--;
	//		System.out.println(array[x]);
	//	}
*/

// B:
// do {
//	 x--;
//	 System.out.println(array[x]);
// } while (x >= 0);

// C:
// while (x >= 0) {
//	 System.out.println(array[x]);
//	 x--;
// }

// D:
// do {
//    System.out.println(array[x]);
//	  --x;
// } while (x >= 0);

/**
	//  E:
	//	while (x > 0) {
	//		System.out.println(array[--x]);
	//	}
*/