package com.sample;

public class Question_115 {
	int count = 0;

	public static void displayMsg() {
		System.out.println("Welcome Visit Count: " + count++); // Line 1
	}

	public static void main(String[] args) {
		Question_115.displayMsg();
		displayMsg(); // Line 2
	}
}

//	A.
//	Welcome Visit Count:0
//	Welcome Visit Count: 1

//	B. Compilation fails at line n2.

/** C. Compilation fails at line n1. */

//	D. Welcome Visit Count:0 Welcome Visit Count: 0