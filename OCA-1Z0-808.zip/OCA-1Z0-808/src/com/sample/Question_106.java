package com.sample;

public class Question_106 {
	public static void main(String[] args) {
		System.out.println("String main " + args[0]);
	}
}

// i)   If we add "1 2 3" means the answer is 1 2 3
// ii)  If we add 123 means the answer is 123
// iii) If we add 1 2 3 means the answer is 1

//	A. String main 1
//	B. An exception is thrown at runtime
/**	C. String main 1 2 3 */
//	D. String main 123