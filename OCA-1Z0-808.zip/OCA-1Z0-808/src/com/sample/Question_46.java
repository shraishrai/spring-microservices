package com.sample;

public class Question_46 {

	public static void main(String[] args) {
		int iVar = 100;
		float fVar = 100.100f;
		double dVar = 123;

		fVar = iVar;
		iVar = fVar;
		fVar = dVar;
		dVar = fVar;
		iVar = dVar;
		dVar = iVar;
	}
}

// Which three lines fail to compile? (Choose three.)
// Answers B, C, E

// A. Line 10
/** B. Line 11 */
/** C. Line 12 */
// D. Line 13
/** E. Line 14 */
// F. Line 15