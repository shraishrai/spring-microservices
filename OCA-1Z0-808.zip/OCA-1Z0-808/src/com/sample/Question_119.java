package com.sample;

public class Question_119 {
	public static void main(String[] args) {
		String str1 = "Java";
		String str2 = new String("java");

		// Line 1

		{
			System.out.println("Equal");
		} else {
			System.out.println("Not-Equal");
		}
	}
}

// Which option make to print "Equal"?

// A.
// str1.toLowerCase();
// if(str1==str2)

/**
	// B.
	// if(str2.equals(str1.toLowerCase()))
*/

// C.
// str1.toLowerCase();
// if(str1.equals(str2))

// D.
// if(str1.toLowerCase()==str2.toLowerCase())