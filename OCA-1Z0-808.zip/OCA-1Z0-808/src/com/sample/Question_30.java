package com.sample;

public class Question_30 {
	public static void main(String[] args) {
		StringBuilder sb1 = new StringBuilder("Duke");
		String str1 = sb1.toString();

		// Line n1

		System.out.println(str1 == str2);
	}
}

// O/P need to be "true"

/** A. String str2 = str1; */
//	B. String str2 = new String(str1);
//	C. String str2 = sb1.toString();
//	D. String str2 = "Duke";
