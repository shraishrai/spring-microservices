package com.sample;

public class Question_60 {
	public static void main(String[] args) {
		String s = "Java SE 8 1";

		int len = s.trim().length();
		System.out.println(len);
	}
}

// A. Compilation fails.
/** B. 11 */
// C. 8
// D. 9
// E. 10
