package com.sample;

public class Question_35 {
	private static String maskCC(String creditCard) {
		String x = "XXXX-XXXX-XXXX-";

		// Line 1

	}

	public static void main(String[] args) {
		System.out.println(maskCC("1234-5678-9101-9876"));
	}

}

/**
 * You must ensure that the maskcc method returns a string that hides all digits
 * of the credit card number except the four last digits (and the hyphens that
 * separate each group of four digits). Which two code fragments should you use
 * at line n1, independently, to achieve this requirement? (Choose two.)
 */

//	Answer is B & C

// 	A. 
//	StringBuilder sb = new StringBuilder(creditCard);
//	sb.substring(15, 19);
//	return x + sb;

/**
	//	B. 
	//	return x + creditCard.substring(15, 19);
	
	// 	C. 
	//	StringBuilder sb = new StringBuilder(x);
	//	sb.append(creditCard, 15, 19);
	//	return sb.toString();
*/

//	D. 
//	StringBuilder sb = new StringBuilder(creditCard);
//	StringBuilder s = sb.insert(0, x);
//	return s.toString();