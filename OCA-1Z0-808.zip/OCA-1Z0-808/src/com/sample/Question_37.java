package com.sample;

class Base {
	public void test() {
		System.out.println("Base ");
	}
}

class DerivedA extends Base {
	public void test() {
		System.out.println("DerivedA ");
	}
}

public class Question_37 extends DerivedA {

	public void test() {
		System.out.println("DerivedB ");
	}

	public static void main(String[] args) {
		Base b1 = new Question_37();
		Base b2 = new DerivedA();
		Base b3 = new Question_37();
		b1 = (Base) b3;
		Base b4 = (DerivedA) b3;

		b1.test();
		b4.test();
	}

}

//	A.
//	Base
//	DerivedA

//	B.
//	Base
//	DerivedB

/**
	//	C.
	//	DerivedB
	//	DerivedB
*/

//	D.
//	DerivedB
//	DerivedA

//	E.
//	A ClassCastException is thrown at runtime.
