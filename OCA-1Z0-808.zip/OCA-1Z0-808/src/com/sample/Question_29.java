package com.sample;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Question_29 {
	public static void main(String[] args) {
		LocalDate l1 = LocalDate.now();
		LocalDate l2 = LocalDate.of(6, 20, 2014);
		LocalDate l3 = LocalDate.parse("2014-06-20", 
				DateTimeFormatter.ISO_DATE);

		System.out.println("date1 = " + l1);
		System.out.println("date2 = " + l2);
		System.out.println("date3 = " + l3);
	}
}

//	A.
//	date1 = 2014-06-20
//	date2 = 2014-06-20
//	date3 = 2014-06-20

//	B. 
//	date1 = 06/20/2014
//	date1 = 2014-06-20
//	date1 = Jun 20, 2014

//	C. Compilation fails.

/** D. An exception is thrown at runtime. */