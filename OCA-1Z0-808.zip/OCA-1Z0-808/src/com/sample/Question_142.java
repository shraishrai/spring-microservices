package com.sample;

public class Question_142 {
	public static void main(String[] args) {
		int sum = 0;
		for (int xVal = 0; xVal <= 5; xVal++) {
			sum = sum + xVal;
		}

		System.out.println("The sum of " + xVal + " number is: " + sum);
	}
}

//	A. The sum of 4 numbers is: 10
/** B. A compile time error occurs. */
//	C. The sum of 5 numbers is: 10
//	D. The sum of 5 numbers is: 15