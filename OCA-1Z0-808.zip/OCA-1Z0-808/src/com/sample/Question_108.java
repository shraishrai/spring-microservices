package com.sample;

import java.time.LocalDate;

public class Question_108 {
	public static void main(String[] args) {
		LocalDate ld = LocalDate.of(2012, 1, 30);
		ld.plusDays(10);

		System.out.println(ld);
	}
}

//	A. 2012-02-10 00:00
/** B. 2012-01-30 */
//	C. 2012-02-10
//	D. A DateTimeException is thrown at runtime.