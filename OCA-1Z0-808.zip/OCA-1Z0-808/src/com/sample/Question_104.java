package com.sample;

public class Question_104 {
	public static void main(String[] args) {
		int x = 1;
		int y = 0;

		if (x++ > ++y) {
			System.out.print("Hello ");
		} else {
			System.out.print("Welcome ");
		}
		System.out.println("Log " + x + " : " + y);
	}
}

//	A. Hello Log 1 : 0
//	B. Hello Log 2 : 1
/**	C. Welcome Log 2 : 1 */
//	D. Welcome Log 1 : 0