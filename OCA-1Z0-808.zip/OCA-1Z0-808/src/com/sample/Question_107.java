package com.sample;

class Vech {
	int x;

	Vech() {
		this(10); // Line 1
	}

	Vech(int x) {
		this.x = x;
	}
}

class Moto extends Vech {
	int y;

	Moto() {
		super(10); // Line 2
	}

	Moto(int y) {
		super(y);
		this.y = y;
	}

	public String toString() {
		return super.x + " : " + this.y;
	}
}

public class Question_107 {
	public static void main(String[] args) {
		Vech v = new Moto(20);
		System.out.println(v);
	}
}

//	A. Compilation fails at line n2.
//	B. Compilation fails at line n1.
/** C. 20:20 */
//	D. 10:20