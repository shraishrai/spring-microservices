package com.sample;

public class Question_17 {
	public static void main(String[] args) {
		boolean opt = true;

		/**
		 * opt we can't able to give instead we can give String opt = "true"; switch
		 * (opt) {
		 */
		switch (opt) {
		case "true":
			System.out.print("True");
			break;
		default:
			System.out.print("****");
		}
		System.out.print("Done");
	}
}

// O/P need to print "TrueDone"

/**
  	// A. Replace line 6 with String opt = "true"; 
   	// Replace line 13 with case "true":
 */

//	B. 	Replace line 6 with boolean opt = 1;
//		Replace line 13 with case 1:

//	C. 	At line 15,remove the break statement.

//	D. 	Remove the default section.