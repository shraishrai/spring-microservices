package com.sample;

public class Question_42 {
	public static void main(String[] args) {
		int[] arr = { 1, 2, 3, 4 };
		int i = 0;

		do {
			System.out.print(arr[i] + " ");
			i++;
		} while (i < arr.length + 1);
	}
}

/** A. 1 2 3 4 followed by an ArrayIndexOutOfBoundsException */
// B. 1 2 3
// C. 1 2 3 4
// D. Compilation fails.