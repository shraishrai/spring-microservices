package com.sample;

class C9 {
	C9() {
		System.out.println("X1");
	}
}

class C8 extends C9 {
	C8() {
		System.out.println("X2");
	}
}

class C7 extends C8 {
	C7() {
		System.out.println("X3");
	}
}

public class Question_141 {

	public static void main(String[] args) {
		C9 obj1 = (C9) new C8(); // Consider as Line 16
		C8 obj2 = (C8) new C7(); // Consider as Line 17
		C8 obj3 = (C8) new C9(); // Consider as Line 18
		C7 obj4 = (C7) obj2; // Consider as Line 19
	}
}

// Which line throws ClassCastException?

/** A. line 18 */
//	B. line 17
//	C. line 19
//	D. line 16