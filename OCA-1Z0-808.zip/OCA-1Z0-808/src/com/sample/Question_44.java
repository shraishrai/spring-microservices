package com.sample;

class Vehicles {
	int x;

	Vehicles() {
		this(10); // line 1
	}

	Vehicles(int x) {
		this.x = x;
	}
}

class Cars extends Vehicles {
	int y;

	Cars() {
		super();
		this(20); // Line 2
	}

	Cars(int y) {
		this.y = y;
	}

	public String toString() {
		return super.x + " : " + this.y;
	}
}

public class Question_44 {
	public static void main(String[] args) {
		Question_44 q = new Question_44();
		q.meth();
	}

	public void meth() {
		Vehicles p = new Cars();
		System.out.println(p);
	}
}

// A. 10:20
// B. 0:20
// C. Compilation fails at line n1
/** D. Compilation fails at line n2 */
