package com.sample;

public class Question_147 {
	public static void main(String[] args) {

	}
}

// Which will produce compile time error?

// Answer A & C

/**
	// 	A. 	
	// 	double d1 = 203.22;
	// 	float f1 = d1;
*/

// 	B. float f2 = (float) 1_11.00;

/** C. Float f3 = 100.00; */

// 	D.
//	int i4 = 100;
//	float f4 = (float) i4;

// 	E. float f5 = 100.00F;
