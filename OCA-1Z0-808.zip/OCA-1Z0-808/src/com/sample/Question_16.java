package com.sample;

public class Question_16 {
	public static void main(String[] args) {
		int x = 5;
		while (isAvailable(x)) {
			System.out.print(x);
			// Line 1

		}
	}

	public static boolean isAvailable(int x) {
		return x-- > 0 ? true : false;
	}
}

// Which option modification is done to get "54321"?

//	A. Replace line 9 with System.out.print(--x) ;
/** B. At line 11, insert x--; */
//	C. Replace line 9 with --x; and, at line 11, insert System.out.print(x);
// 	D. Replace line 17 with return (x > 0) ? false: true;