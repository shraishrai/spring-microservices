package com.sample;

class Alphas {
	int ns;
	static int s;
	Alphas(int ns) {
		if (s < ns) {
			s = ns;
			this.ns = ns;
		}
	}

	void doPrint() {
		System.out.println("ns = " + ns + " s = " + s);
	}
}

public class Question_139 {
	public static void main(String[] args) throws Exception {
		Alphas a1 = new Alphas(100);
		Alphas a2 = new Alphas(50);
		Alphas a3 = new Alphas(125);
		a1.doPrint();
		a2.doPrint();
		a3.doPrint();
	}
}

/**
	//	A. 
	//	ns = 100 s = 125 
	//	ns = 0 s = 125 
	//	ns = 125 s = 125 
*/

//	B.
//	ns = 50 s = 50
//	ns = 125 s = 125
//	ns = 0 s = 125

//	C.
//	ns = 50 s = 125 
//	ns = 125 s = 125 
//	ns = 0 s = 125 

//	D.
//	ns = 50 s = 50 
//	ns = 125 s =125 
//	ns = 100 s =100