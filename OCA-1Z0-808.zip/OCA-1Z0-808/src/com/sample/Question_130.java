package com.sample;

public class Question_130 {
	public static void main(String[] args) {
		String ta = "A ";
		ta = ta.concat("B ");
		String tb = "C ";
		ta = ta.concat(tb);
		ta.replace("B", "C");
		ta = ta.concat("D ");
		System.out.println(ta);
	}
}

/** A. A B C D */
//	B. A C D
//	C. A C D D
//	D. A B C C
//	E. A B D C