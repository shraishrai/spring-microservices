package com.sample;

class Vehicle {
	String type = "4W";
	int maxSpeed = 100;

	Vehicle(String type, int maxSpeed) {
		this.type = type;
		this.maxSpeed = maxSpeed;
	}

	Vehicle() {
	}
}

class Car extends Vehicle {
	String trans;

	Car(String trans) { // Line 1
		this.trans = trans;
	}

	Car(String type, int maxSpeed, String trans) {
		super(type, maxSpeed); // Line 2
		this.trans = trans;
	}
}

public class Question_05 {
	public static void main(String[] args) {
		Car q = new Car("Auto");
		Car q1 = new Car("4W", 150, "Manual");
		System.out.println(q.type + " " + q.maxSpeed + " " + q.trans);
		System.out.println(q1.type + " " + q1.maxSpeed + " " + q1.trans);
	}
}

/** A. 4W 100 Auto 4W 150 Manual */
// B. null 0 Auto 4W 150 Manual
// C. Compilation fails only at line n1
// D. Compilation fails only at line n2
// E. Compilation fails only at line n1 and line n2
