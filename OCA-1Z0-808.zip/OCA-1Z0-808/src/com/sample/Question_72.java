package com.sample;

public class Question_72 {
	int count;

	public static void displayMsg() {
		count++; // Line 1
		System.out.println("Welcome Visit Count: " + count); // Line 2
	}

	public static void main(String[] args) {
		Question_72.displayMsg(); // Line 3
		Question_72.displayMsg(); // Line 4
	}
}

// A. Compilation fails at line n3 and line n4.

/**
 	// B. Compilation fails at line n1 and line n2.
*/

// C.
// Welcome Visit Count:1
// Welcome Visit Count: 1

// D. Welcome Visit Count:1 Welcome Visit Count: 2
