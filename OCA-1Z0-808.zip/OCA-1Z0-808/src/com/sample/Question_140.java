package com.sample;

public class Question_140 {
	public static void main(String[] args) throws Exception {
		// Which two array initialisation statements are valid? (Choose two.)
	
	}
}

// Answer is B & E

//	A. int array[] = new int[3] {1, 2, 3};

/**	
	//	B. 
	//	int array[] = new int[3]; 
	//	array[0] = 1;
	//	array[1] = 2;
	//	array[2] = 3;
*/

//	C. int array[3] = new int[] {1, 2, 3};

//	D.
//	int array[] = new int[3];
//	array = {1, 2, 3};

/**	E. int array[] = new int[] {1,2,3}; */