package com.sample;

class Product {
	double price;
}

public class Question_01 {
	public static void main(String[] args) {
		Product product = new Product();
		product.price = 200;
		double newPrice = 100;

		Question_01 q1 = new Question_01();
		q1.updatePrice(product, newPrice);
		System.out.println(product.price + " : " + newPrice);
	}

	public void updatePrice(Product product, double price) {
		price = price * 2;
		product.price = product.price + price;
	}
}

// A. 200.0 : 100.0
// B. 400.0 : 200.0
/** C. 400.0 : 100.0 */
// D. Compilation fails