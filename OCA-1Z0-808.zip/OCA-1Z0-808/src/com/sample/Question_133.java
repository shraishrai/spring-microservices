package com.sample;

public class Question_133 {
	public static void main(String[] args) {
		int x;

		// Line 1
		
	}
}

//Which two code fragments inserted at Line 1 print "****"?

/**
	//	A.
	//	x = 3;
	//	do {
	//		System.out.print("*");
	//		x--;
	//	} while (x >= 0);
*/

//	B.
//	x = 0;
//	do {
//		System.out.print("*");
//		x++;
//	} while (x >= 3);

//	C.
//	x = 0;
//	do {
//		System.out.print("*");
//		++x;
//	} while (x > 3);

//	D.
//	x = 30;
//	do {
//		System.out.print("*");
//		x--;
//	} while (x != 1);
	
/**
	//  E:
	//	x = 0;
	//	do {
	//		System.out.print("*");
	//	} while (x++ < 3);
*/