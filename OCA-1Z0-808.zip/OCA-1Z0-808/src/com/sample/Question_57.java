package com.sample;

public class Question_57 {
	int x;
	int y;

	public void doStuff(int x, int y) {
		x = x;
		y = this.y;
	}

	public void display() {
		System.out.print(x + " " + y + " : ");
	}

	public static void main(String[] args) {
		Question_57 q = new Question_57();
		q.x = 100;
		q.y = 200;

		Question_57 q1 = new Question_57();
		q1.doStuff(q.x, q.y);

		q.display();
		q1.display();
	}
}

/** A. 100 200 : 0 0 : */
// B. 100 200 : 100 0 : 
// C. 100 200 : 100 200 :
// D. 0 0 : 100 0 :