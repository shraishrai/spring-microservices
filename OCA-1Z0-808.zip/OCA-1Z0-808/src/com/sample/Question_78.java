package com.sample;

public class Question_78 {
	char c;
	boolean b;
	float f;

	void printAll() {
		System.out.println("c = " + c);
		System.out.println("b = " + b);
		System.out.println("f = " + f);
	}

	public static void main(String[] args) {
		Question_78 q = new Question_78();
		q.printAll();
	}
}

/**
	//  A.
	//	c =  
	//	b = false
	//	f = 0.0
*/

// 	B.
//	c =  null
//	b = true
//	f = 0.0

// 	C.
//	c =  0
//	b = false
//	f = 0.0f

// 	D.
//	c =  null
//	b = false
//	f = 0.0F