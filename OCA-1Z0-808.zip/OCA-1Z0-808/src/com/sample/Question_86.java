package com.sample;

interface Exportable {
	void export();
}

class Tool implements Exportable {
	protected void export() { // Line 1
		System.out.println("Tool::export");
	}
}

public class Question_86 extends Tool implements Exportable {
	public void export() { // Line 2
		System.out.println("RTool::export");
	}

	public static void main(String[] args) {
		Tool aTool = new Question_86();
		Tool bTool = new Tool();

		callExport(aTool);
		callExport(bTool);
	}

	public static void callExport(Exportable ex) {
		ex.export();
	}
}

//	A. Compilation fails only at line n2.

//	B.
//	RTool::export
//	Tool::export

//	C.
//	Tool::export
//	Tool:export

/** D. Compilation fails only at line n1. */

//	E. Compilation fails at both line n1 and line n2.