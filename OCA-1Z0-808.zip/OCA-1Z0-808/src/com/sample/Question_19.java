package com.sample;

public class Question_19 {
	public static void main(String[] args) {
		int x = 100;
		int a = x++;
		int b = ++x;
		int c = x++;

//		int d = (100 < 102) ? (100 < 102) ? 100 : (102 < 102) ? 102 : 102 : 103;
		int d = (a < b) ? (a < c) ? a : (b < c) ? b : c : x;

		System.out.println(d);
	}
}

/** A. 100 */
//	B. 101
//	C. 102
// 	D. 103
//	E. Compilation fails