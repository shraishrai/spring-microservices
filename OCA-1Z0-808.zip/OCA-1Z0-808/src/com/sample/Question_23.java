package com.sample;

class A {
	public A() {
		System.out.print("A ");
	}
}

class B extends A {
	public B() { // Line n1
		System.out.print("B ");
	}
}

public class Question_23 extends B {
	public Question_23() { // Line n2
		System.out.print("C ");
	}

	public static void main(String[] args) {
		Question_23 q = new Question_23();
	}
}

//	A. C B A
//	B. C
/** C. A B C */
//	D. Compilation fails at line n1 and line n2
