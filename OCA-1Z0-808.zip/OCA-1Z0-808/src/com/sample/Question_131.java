package com.sample;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public class Question_131 {

	public static void main(String[] args) {
		List<String> lst = Arrays.asList("A", "B", "C", "D");
		Iterator<String> itr = lst.iterator();

		while (itr.hasNext()) {
			String e = itr.next();

			if (e == "C") {
				break;
			} else {
				continue;
				System.out.println(e);
			}
		}
	}
}

//	A. Comment lines 18 to 21.
//	B. Comment line 20.
/** C. Comment line 19. */
//	D. Comment line 16.
