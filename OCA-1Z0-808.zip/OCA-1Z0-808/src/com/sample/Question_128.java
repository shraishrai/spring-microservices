package com.sample;

class Testing {
	String msg;

	Testing(String msg) {
		this.msg = msg;
	}
}

public class Question_128 {
	public static void main(String[] args) {
		System.out.println("Hello " + new StringBuilder("Java SE 8"));
		System.out.println("Hello " + new Testing("Java SE 8").msg);
	}
}

/**
	//	A.
	//	Hello Java SE 8
	//	Hello Java SE 8
*/

//	B.
//	Hello java.lang.StringBuilder@<<hascode1>>
//	Hello p1.MyString@<<hashcode2>>

//	C.
//	Hello Java SE 8
//	Hello p1.MyString@<<hashcode2>>

//	D. Compilation fails at the Test class