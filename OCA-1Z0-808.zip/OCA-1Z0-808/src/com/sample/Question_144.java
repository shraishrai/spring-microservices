package com.sample;

class P1 { }

class P2 extends P1 implements I10 { }

interface I10 { }

public class Question_144 {
	public static void main(String[] args) {
		P1 obj = new P1();
		P2 obj2 = new P2();
		I10 obj3 = new P2();

		boolean b1 = obj instanceof P2;
		boolean b2 = obj2 instanceof P1;
		boolean b3 = obj3 instanceof I10;

		System.out.println(b1 + " : " + b2 + " : " + b3);
	}
}

//	A. true : false : true
/** B. false : true : true */
//	C. false : true : false
//	D. true : true : false
