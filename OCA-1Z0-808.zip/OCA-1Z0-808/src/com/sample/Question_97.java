package com.sample;

abstract class Toys {
	int price;

	// Line 1

}

public class Question_97 {
	public static void main(String[] args) {

	}
}

/**
	//  A:
	//	public static void insertToy() {
	//	
	//	}
*/

// B:
// final Toys getToy() { }

// C:
// public void printToy();

/**
	//  D:
	//	public int calculatePrice() {
	//		return price;
	//	}
	
	//  E:
	//	public abstract int computeDiscount();
*/