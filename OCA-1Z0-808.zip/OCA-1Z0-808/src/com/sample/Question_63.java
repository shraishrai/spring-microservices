package com.sample;

public class Question_63 {
	public static void main(String[] args) {
		StringBuilder sb = new StringBuilder("Hai Kishore");
		System.out.println(sb.toString());

		// Line 1

		System.out.println(sb.toString() + " Printed");
	}
}

// Which statement will empty the contents of a StringBuilder variable named sb?

// A. sb.deleteAll();
// B. sb.delete(0, sb.size());
/** C. sb.delete(0, sb.length()); */
// D. sb.removeAll();