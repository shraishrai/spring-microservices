package com.sample;

// Consider Question_129 class as Test class
public class Question_129 {
	public static void main(String[] args) {
		Question_129 ts = new Question_129();
		System.out.print(isAvailable + " ");
		isAvailable = ts.doStuff();
		System.out.print(isAvailable);
	}

	public static boolean doStuff() {
		return !isAvailable;
	}

	static boolean isAvailable = true;
}

//	A. Compilation fails.
//	B. false true
/** C. true false */
//	D. true true
//	E. false false