package com.sample;

class Emp {
	public int salary;
}

class Mgr extends Emp {
	public int budget;
}

class Director extends Mgr {
	public int stockOptions;
}

public class Question_151 {

	public static void main(String[] args) {
		Emp emp = new Emp();
		Mgr mgr = new Mgr();
		Director dct = new Director();

		// Line 1
		emp.salary = 50_000;
		dct.salary = 80_000;
		emp.budget = 200_000;
		mgr.budget = 1_000_000;
		mgr.stockOption = 500;
		dct.stockOptions = 1_000;
	}
}

// Which give compile time error?

// Answer C & E

// A. emp.salary = 50_000;
// B. dct.salary = 80_000;
/** C. emp.budget = 200_000; */
// D. mgr.budget = 1_000_000;
/** E. mgr.stockOption = 500; */
// F. dct.stockOptions = 1_000;