package com.sample;

public class Question_102 {
	public static void main(String[] args) {

	}
}

// Which two options will make compile time error?
// Answer is C & E

//  A.
//	abstract class A3 {
//		private static int i;
//	
//		public void doStuff() {
//		}
//	
//		public A3() {
//		}
//	}

//  B.
//	final class A4 {
//		public A4() {
//		}
//	}

/**
	// C.
	// private class A5 {
	//	 private static int i;
	//
	//	 private A5() {
	//
	//	 }
	// }
*/

//  D.
//	class A6 {
//		protected static final int i = 10;
//	
//		private A6() {
//		}
//	}

/**
	// E.
	// final abstract class A7 {
	//	
	// }
*/