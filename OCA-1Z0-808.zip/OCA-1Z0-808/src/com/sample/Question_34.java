package com.sample;

public class Question_34 {
	public static void main(String[] args) {
		String[] planets = { "Mercury", "Venus", "Earth", "Mars" };

		System.out.println(planets.length);
		System.out.println(planets[1].length());
	}

}

//	A. 4 4
//	B. 3 5
//	C. 4 7
//	D. 5 4
/** E. 4 5 */
//	F. 4 21
