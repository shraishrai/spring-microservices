package com.sample;

interface Downloadable {
	public void download();
}

interface Reading extends Downloadable { // Line 1
	public void readBook();
}

abstract class Booking implements Reading { // Line 2
	public void readBook() {
		System.out.println("Read Book");
	}
}

public class Question_95 extends Booking { // Line 3
	public static void main(String[] args) {
		Booking book1 = new Question_95();
		book1.readBook();
	}

	public void readBook() {
		System.out.println("Read E-Book");
	}
}

//	A. Compilation fails at line n2.
//	B. Read Book
// 	C. Read E-Book
// 	D. Compilation fails at line n1.
/** E. Compilation fails at line n3. */
