package com.sample;

import java.util.ArrayList;
import java.util.List;

public class Question_22 {
	public static void main(String[] args) {
		List<String> names = new ArrayList<String>();
		names.add("Robb");
		names.add("Bran");
		names.add("Rick");
		names.add("Bran");

		if (names.remove("Bran")) {
			names.remove("Jon");
		}

		System.out.println(names);
	}
}

/** A. [Robb, Rick, Bran] */
//	B. [Robb, Rick]
//	C. [Robb, Bran, Rick, Bran]
//	D. An Exception is thrown at runtime
