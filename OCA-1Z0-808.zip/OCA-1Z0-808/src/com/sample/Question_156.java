package com.sample;

import java.util.ArrayList;
import java.util.List;

class Proudct {
	int id;
	String name;

	public Proudct(int id, String name) {
		this.id = id;
		this.name = name;
	}
}

public class Question_156 {
	public static void main(String[] args) {
		List<Proudct> lst = new ArrayList<>();
		lst.add(new Proudct(10, "IceCream"));
		lst.add(new Proudct(11, "Chocolate"));

		Proudct p1 = new Proudct(10, "IceCream");
		System.out.println(lst.indexOf(p1));
	}
}

//	A. true
//	B. false
/** C. -1 */
//	D. 0
