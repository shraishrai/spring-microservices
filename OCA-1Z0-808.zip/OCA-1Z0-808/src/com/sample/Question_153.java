package com.sample;

public class Question_153 {
	public static void main(String[] args) {
		int numbers[] = { 12, 23, 34, 45, 56, 78, 88 };
		int[] keys = findMax(numbers);
	}

	static int[] findMax(int[] max) {
		return null;
	}
}
