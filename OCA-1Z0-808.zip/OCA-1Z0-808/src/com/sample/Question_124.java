package com.sample;

public class Question_124 {
	public static void main(String[] args) {
		int x = 6;
		while (isAvailable(x)) { // Consider as Line 5
			System.out.print(x); // Consider as Line 6
			// Consider as Line 7
		}
	}

	public static boolean isAvailable(int x) {
		return --x > 0 ? true : false; // Consider as Line 12
	}
}

// Which option modification is done to get "54321"?

/** A. Replace line 6 with System.out.print (--x); */
//	B. At line 7, insert x --;
//	C. Replace line 5 with while (is Available(--x)) {
//	D. Replace line 12 with return (x > 0) ? false : true;