package com.sample;

class C {
	public C() {
		System.out.print("C ");
	}
}

class B0 extends C {
	public B0() {
		System.out.print("B ");
	}
}

public class Question_112 extends B0 {
	public Question_112() {
		System.out.print("A ");
	}

	public static void main(String[] args) {
		Question_112 q = new Question_112();
	}
}

/** A. C B A */
//	B. C
//	C. A B C
//	D. Compilation fails at line n1 and line n2