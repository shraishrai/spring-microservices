package com.sample;

import java.io.IOException;

class K {
	public void printFileContent() {
		// Line 1

		throw new IOException();
	}
}

public class Question_159 {
	public static void main(String[] args) {
		K k = new K();
		k.printFileContent();
	}
}

// Answer is C & E

//  A.
//	try {
//		xobj.printFileContent();
//	} catch(Exception e) {
//		
//	} catch(IOException ie) {
//		
//	}

//	B. Replace line 7 with throw IOException (“Exception raised”);

/**
 * C. Replace line 11 with public static void main(String[]) args) throws
 * Exception {
 */

//	D. At line 14, insert throw new IOException();

/**
 * // E. Replace line 5 with public void printFileContent() throws IOException {
 */
