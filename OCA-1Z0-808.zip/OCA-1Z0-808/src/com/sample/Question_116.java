package com.sample;

interface AI {
	public void displayAI();
}

abstract class C2s implements AI {
	public void displayC2() {
		System.out.print("C2");
	}
}

class C1 extends C2s {
	public void displayAI() {
		System.out.print("C1");
	}
}

public class Question_116 {
	public static void main(String[] args) {
		C2s obj1 = new C1();
		AI obj2 = new C1();

		C2s s = (C2s) obj2;
		AI t = obj1;

		t.displayAI();
		s.displayC2();
	}
}

/** A. C1C2 */
//	B. C1C1
//	C. Compilation fails.
//	D. C2C2
