package com.sample;

public class Question_74 {
	static int count = 0;
	int i = 0;

	public void changeCount() {
		while (i < 5) {
			i++;
			count++;
		}
	}

	public static void main(String[] args) {
		Question_74 q1 = new Question_74();
		Question_74 q2 = new Question_74();

		q1.changeCount();
		q2.changeCount();

		System.out.println(q1.count + " : " + q2.count);
	}
}

// A. 5: 5
/** B. 10 : 10 */
// C. 5 : 10
// D. Compilation fails.
