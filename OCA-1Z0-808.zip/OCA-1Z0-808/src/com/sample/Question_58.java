package com.sample;

public class Question_58 {
	private char var;
	public static void main(String[] args) {
		char var1 = 'a';
		char var2 = var1;
		var2 = 'e';

		Question_58 q1 = new Question_58();
		Question_58 q2 = q1;

		q1.var = 'o';
		q2.var = 'i';

		System.out.println(var1 + ", " + var2);
		System.out.println(q1.var + ", " + q2.var);
	}
}

/**
	// A.
	// a, e
	// i, i
*/

// B.
// a, e
// o, o

// C.
// e, e
// i, i

// D.
// a, a 
// o, o