package com.sample;

public class Question_61 {
	public static void main(String[] args) {
		boolean a = new Boolean(Boolean.valueOf(args[0]));
		boolean b = new Boolean(args[1]);

		System.out.println(a + " " + b);
	}
}

// Args as -> 0 null

// A. 1 null
// B. true false
/** C. false false */
// D. true true
// E. A ClassCastException is thrown at runtime.