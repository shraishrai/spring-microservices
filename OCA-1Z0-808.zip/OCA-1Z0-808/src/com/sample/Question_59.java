package com.sample;

public class Question_59 {
	public static void main(String[] args) {
		int aVar = 9;

		if (aVar++ < 10) {
			System.out.println(aVar + " Hello Universe!");
		} else {
			System.out.println(aVar + " Hello Worlds!");
		}
	}
}

// A. Compilation fails.
/** B. 10 Hello Universe! */
// C. 10 Hello World!
// D. 9 Hello World!