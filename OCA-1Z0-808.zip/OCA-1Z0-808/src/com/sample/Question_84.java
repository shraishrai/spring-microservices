package com.sample;

public class Question_84 {
	public static final int MIN = 1;

	public static void main(String[] args) {
		int x = args.length;

		if (checkLimit(x)) {
			System.out.println("Java SE");
		} else {
			System.out.println("JAVA EE");
		}
	}

	public static boolean checkLimit(int x) {
		return (x >= MIN) ? true : false;
	}
}

/** A. Java SE */
//	B. Java EE
//	C. Compilation fails at line n1.
//	D. A NullPointerException is thrown at runtime.