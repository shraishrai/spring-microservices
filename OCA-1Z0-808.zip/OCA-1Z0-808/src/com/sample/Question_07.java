package com.sample;

class Customer {
	ElecticAccount acct = new ElecticAccount();
	public void useElecticity(double kWh) {
		acct.addKWh(kWh);
	}
}

class ElecticAccount {
	private double kWh;
	private double rate = 0.07;
	private double bill;

	// Line 1
	public void addKWh(double kWh) {
		this.kWh += kWh;
		this.bill = this.kWh * this.rate;
	}

	@Override
	public String toString() {
		return "ElecticAccount [kWh=" + kWh + ", rate=" + rate + ", bill=" + bill + "]";
	}

}

public class Question_07 {

	public static void main(String[] args) {
		Customer c = new Customer();
		c.useElecticity(100);

		System.out.println(c.acct);
	}

}

/**
 * A. ElecticAccount [kWh=100.0, rate=0.07, bill=7.000000000000001]
 * B. ElecticAccount [kWh=100.0, rate=0.07, bill=7.000000000000001]
 * C. Compilation Error
 * D. ElecticAccount [kWh=100.0, rate=0.07, bill=7.000000000000001]
 * */

// ANSWER: 

//	A.
//	public void addKWh(double kWh) {
//		this.kWh += kWh;
//		this.bill = this.kWh * this.rate;
//	}

//	B.
//	public void addKWh(double kWh) {
//		if(kWh > 0){
//			this.kWh += kWh;
//			this.bill = this.kWh * this.rate;
//		}
//	}

//	C.
//	private void addKWh(double kWh) {
//		if(kWh > 0){
//			this.kWh += kWh;
//			this.bill = this.kWh * this.rate;
//		}
//	}

// 	D.
//	public void addKWh(double kWh) {
//		if(kWh > 0){
//			this.kWh += kWh;
//			setBill(this.kWh);
//		}
//	}
//	public void setBill(double kWh) {
//		bill = kWh * rate;
//	}