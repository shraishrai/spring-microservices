package com.sample;

abstract class Planet {
	protected void resolve() { // Line 1

	}

	abstract void rotate(); // Line 2
}

class Earth extends Planet {
	void resolve() { // Line 3

	}

	protected void rotate() { // Line 4

	}
}

public class Question_04 {
	public static void main(String[] args) {

	}
}

// Which two modifications, made independently, enable the code to compile? (Choose two.)

// A. Make the method at line n1 public.
// B. Make the method at line n2 public.
/** C. Make the method at line n3 public. */
/** D. Make the method at line n3 protected. */
// E. Make the method at line n4 public.
