package com.sample;

import java.util.ArrayList;
import java.util.List;

public class Question_143 {
	public static void main(String[] args) {
		List<String> arrayList = new ArrayList<String>();
		arrayList.add("Tech");
		arrayList.add("Expert");
		arrayList.set(0, "Java");
		arrayList.forEach(a -> a.concat("Forum"));
		arrayList.replaceAll(s -> s.concat("Group"));

		System.out.println(arrayList);
	}
}

//	A. [JavaForum, ExpertForum]
/** B. [JavaGroup, ExpertGroup] */
//	C. [JavaForumGroup, ExpertForumGroup]
//	D. [JavaGroup, TechGroup ExpertGroup]