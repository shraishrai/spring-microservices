package com.sample;

class Employiee {
	public int salary;
}

class Managier extends Employiee {
	public int budget;
}

class Directior extends Managier {
	public int stockOptions;
}

public class Question_155 {
	public static void main(String[] args) {

		Employiee employee = new Employiee();
		Employiee manager = new Managier();
		Employiee director = new Directior();

		// Line 1

	}
}

//  Which two options compile when placed at line n1 of the main method? (Choose two.)

// Answer is B & F

//	A. director.stockOptions = 1_000;
/** B. employee.salary = 50_000; */
//	C. manager.budget = 1_000_000;
//	D. manager.stockOption = 500;
//	E. employee.budget = 200_000;
/** F. director.salary = 80_000; */