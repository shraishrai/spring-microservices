package com.sample;

//Line 1


public class Question_149 {

	public static void main(String[] args) {
		SalesMan sm;
		Products ps;
	}
}

// A. import sales.*;

// B. import java.sales.products.*;

// C. import sales; 
// 	  import sales.products;

// D. import sales.*; 
//	  import products.*;

/** E. import sales.*; 
	   import sales.products.*; */