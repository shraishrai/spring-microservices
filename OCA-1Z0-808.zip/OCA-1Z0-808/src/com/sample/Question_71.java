package com.sample;

public class Question_71 {
	public static void main(String[] args) {
		System.out.println("Result A " + 0 + 1);
		System.out.println("Result B " + (1) + (2));
	}
}


// A.
// Result A 01
// Result B 3

// B.
// Result A 1
// Result B 12

// C.
// Result A 1
// Result B 3

/*
	// D.
	// Result A 01
	// Result B 12
*/
