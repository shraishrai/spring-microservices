package com.sample;

class MyException extends RuntimeException { }

public class Question_53 {
	public static void main(String[] args) {
		try {
			method1();
		} catch (MyException e) {
			System.out.println("A");
		}
	}

	public static void method1() { // Line 1
		try {
			throw Math.random() > 0.5 ? new MyException() : new RuntimeException();
		} catch (RuntimeException e) {
			System.out.println("B");
		}
	}
}

// A. A
/** B. B */
// C. Either A or B
// D. AB
// E. A compile time error occurs at line n1