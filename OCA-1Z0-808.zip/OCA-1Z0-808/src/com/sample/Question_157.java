package com.sample;

class Cart {
	Pro p;
	double totalAmount;
}

class Pro {
	String name;
	Double price;
}

public class Question_157 {
	public static void main(String[] args) {
		Cart c = new Cart();
		System.out.println(c.p + ":" + c.totalAmount);
	}
}

//	A. null:null:0.0
//	B. null:null
//	C. <<HashCode>>:0.0
/** D. null:0.0 */