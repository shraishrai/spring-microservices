package com.sample;

public class Question_40 {
	public static void main(String[] args) {
		String s = " ";
		s.trim();

		System.out.println(s.equals("") + " " + s.isEmpty());
	}
}

// A. true true
// B. true false
/** C. false false */
// D. false true