package com.sample;

class C2 {
	public void displayC2() {
		System.out.println("C2");
	}
}

interface I {
	public void displayI();
}

public class Question_89 extends C2 implements I {
	public void displayI() {
		System.out.println("C1");
	}

	public static void main(String[] args) {
		C2 obj1 = new Question_89();
		I obj2 = new Question_89();

		C2 s = obj2;
		I t = obj1;

		t.displayI();
		s.displayC2();

	}
}

//	A. C2C2
//	B. C1C2
//	C. C1C1
/** D. Compilation fails */
