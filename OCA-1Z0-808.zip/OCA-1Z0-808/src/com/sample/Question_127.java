package com.sample;

class Based {
	public void test() {
		System.out.println("Base ");
	}
}

class DervA extends Based {
	public void test() {
		System.out.println("DerivedA ");
	}
}

// Consider Question_127 as DerivedB
public class Question_127 extends DervA {
	public void test() {
		System.out.println("DerivedB ");
	}

	public static void main(String[] args) {
		Based b1 = new Question_127();
		Based b2 = new DervA();
		Based b3 = new Question_127();
		Based b4 = b3;

		b1 = (Based) b2;
		b1.test();
		b4.test();
	}
}

//	A.
//	Base
//	DerivedA

//	B.
//	Base
//	DerivedB

//	C.
//	DerivedB
//	DerivedB

/**
	//	D.
	//	DerivedA
	//	DerivedB
*/

//	E. A ClassCastException is thrown at runtime.