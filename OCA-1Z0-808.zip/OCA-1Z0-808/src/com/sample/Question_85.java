package com.sample;

class CheckingAccount {
	public int amount;
	// Line 1

}

public class Question_85 {
	public static void main(String[] args) {
		CheckingAccount acct = new CheckingAccount();
		// Line 2
		
	}
}

/**
	// A.
	// At Line 1 insert:
	// public CheckingAccount() {
	//    amount = 100;
	// }
*/

// B.
// At Line 2 insert:
// this.amount = 100;

// C.
// At Line 2 insert:
// amount = 100;

/**
	// D.
	// At Line 1 insert:
	// public CheckingAccount() {
	//    this.amount = 100;
	// }
	
	// E.
	// At Line 2 insert:
	// acct.amount = 100;
*/

// F.
// At Line 1 insert:
// public CheckingAccount() {
//    acct.amount = 100;
// }