package com.sample;

public class Question_31 {
	public static void main(String[] args) {
		Question_31 ts = new Question_31();
		System.out.print(isAvailable + " ");

		isAvailable = ts.doStuff();
		System.out.print(isAvailable);
	}

	public static boolean doStuff() {
		return !isAvailable;
	}

	static boolean isAvailable = false;
}

//	A. Compilation fails.
/**	B. false true */
//	C. true false
//	D. true true
//	E. false false
