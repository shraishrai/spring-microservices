package com.sample;

abstract class Planets {
	// Consider as Line 2
	protected void revolve() { }

	// Consider as Line 4
	abstract void rotate();
}

class Earths extends Planets {
	// Consider as Line 8
	private void revolve() { }

	// Consider as Line 10
	private void rotate() { }
}

public class Question_114 {
	public static void main(String[] args) {

	}
}

//	Which two modifications enable the code to compile?

// Answer is A & C

/** A. Make the method at line 8 protected. */

// B. Make the method at line 8 public.

/** C. Make the method at line 10 protected */

//	D. Make the method at line 4 public.

//	E. Make the method at line 2 public.
