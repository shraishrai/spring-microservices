package com.sample;

// Line 1

public class Question_90 {
	public void matchShirt() {
		// Line 2

		if (color.equals("Green")) {
			System.out.println("Fit");
		}
	}

	public static void main(String[] args) {
		Question_90 q = new Question_90();
		q.matchShirt();
	}
}

// Answer A & C

/**
	//	A.
	//	At line n1 insert: import clothing.Shirt;
	//	At line n2 insert: String color = Shirt.getColor();
*/

//	B.
//	At line n1 insert: import clothing;
//	At line n2 insert: String color = Shirt.getColor();

/**
	//	C.
	//	At line n1 insert: import static clothing.Shirt.getColor;
	//	At line n2 insert: String color = getColor();
*/

//	D.
//	At line n1 no changes required.
//	At line n2 insert: String color = Shirt.getColor();

//	E.
//	At line n1 insert: import Shirt;
//	At line n2 insert: String color = Shirt.getColor();