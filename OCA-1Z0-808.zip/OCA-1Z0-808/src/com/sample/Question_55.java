package com.sample;

public class Question_55 {
	public static void main(String[] args) {
		int num1[] = { 1, 2, 3 };
		int num2[] = { 1, 2, 3, 4, 5 };

		num2 = num1;

		for (int i : num2) {
			System.out.print(i + " : ");
		}
	}
}

// A. 1 : 2 : 3 : 4 : 5 : 
/** B. 1 : 2 : 3 : */
// C. Compilation fails.
// D. An ArrayOutOfBoundsException is thrown at runtime.