package com.sample;

public class Question_41 {
	public static void main(String[] args) {
		String str1 = "Java";
		String str2 = new String("java");

		// LINE 1

		{
			System.out.println("Equals");
		} else {
			System.out.println("Not Equals");
		}
	}
}

// Which code fragment, when inserted at line n1, enables the App class to print Equal?

//	A.
//	str1.toLowerCase();
//	if (str1 == str2)

/**
	//	B.
	//	if(str2.equals(str1.toLowerCase()))
*/

//	C.
//	str1.toLowerCase();
//	if(str1.equals(str1.toLowerCase()))

//	D.
//	if(str1.toLowerCase() == str2.toLowerCase())

