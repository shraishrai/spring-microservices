package com.sample;

public class Question_80 {
	public static void main(String[] args) {
		String myStr = "Hello World ";
		myStr.trim();

		int i = myStr.indexOf(" ");
		System.out.println(i);
	}
}

// A. An exception is thrown at runtime.
// B. -1
/** C. 5 */
// D. 10