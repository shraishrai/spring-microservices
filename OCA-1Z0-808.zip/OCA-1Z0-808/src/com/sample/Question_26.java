package com.sample;

public class Question_26 {
	public static void main(String[] args) {
		String[] arr = { "A", "B", "C", "D" };

		for (int i = 0; i < arr.length; i++) {
			System.out.print(arr[i] + " ");

			if (arr[i].equals("C")) {
				continue;
			}

			System.out.print("Work done");
			break;
		}
	}
}

//	A. A B C Work done
//	B. A B C D Work done
/**	C. A Work done */
//	D. Compilation fails
