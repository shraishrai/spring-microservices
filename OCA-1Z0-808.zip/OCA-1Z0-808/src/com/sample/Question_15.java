package com.sample;

public class Question_15 {

	void readCard(int cardNo) throws Exception {
		System.out.println("Reading Card..");
	}

	void checkCard(int cardNo) throws RuntimeException // Line 1
	{
		System.out.println("Checking Card..");
	}

	public static void main(String[] args) {
		Question_15 q = new Question_15();
		int cardNo = 12344;

		q.readCard(cardNo); // Line 2
		q.checkCard(cardNo);// Line 3	
	}
}

//	A. Reading Card.. Checking Card..
//	B. Compilation fails only at line n1.
/** C. Compilation fails only at line n2. */
//  D. Compilation fails only at line n3. 
//	E. Compilation fails at both line n2 and line n3.