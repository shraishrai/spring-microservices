package com.p1;

public class Shirt {

	public static String getColor() {
		return "Green";
	}
}
